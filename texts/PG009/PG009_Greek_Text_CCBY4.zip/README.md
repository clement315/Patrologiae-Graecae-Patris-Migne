# PG 09 Greek text

Version 1.0.0. Clement of Alexandria, volume II.

Source edition: J.-P. Migne, Patrologiae Graecae cursus completus, tomus IX.
Digital transcription and corrections: PG_OCR project. This text records the spelling and physical line divisions of the Migne edition as reviewed in the project. The JSONL file holds one record per printed column. In the TXT file, headings identify the printed columns.

Attribution: PG_OCR project, PG 09 Greek text, version 1.0.0, from Migne's Patrologia Graeca IX.
The project's transcription and editorial contributions are offered under Creative Commons Attribution 4.0 International.
License: https://creativecommons.org/licenses/by/4.0/
